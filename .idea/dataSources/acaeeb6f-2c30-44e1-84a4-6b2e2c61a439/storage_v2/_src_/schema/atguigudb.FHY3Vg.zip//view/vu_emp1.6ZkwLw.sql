create definer = root@localhost view vu_emp1 as
select `atguigudb`.`employees`.`employee_id` AS `employee_id`,
       `atguigudb`.`employees`.`last_name`   AS `last_name`,
       `atguigudb`.`employees`.`salary`      AS `salary`
from `atguigudb`.`employees`;

